#pragma once
#include "Character.h"
class CharacterOnSkillDuck1 :
	public Character
{
private:
	static constexpr Uint32		HIGHIST_TIME = 250;
	static constexpr Uint32		GO_DOWN_TIME = 350;

	static constexpr double		GO_UP_V = -GRAVITY * 0.25;
	static constexpr Vector2d<double> offset[5]
		= { { 0.86, 0.5 }, {0.71, 0.71}, {0, 1}, {-0.71, 0.71}, {-0.86, 0.5} };


public:
	CharacterOnSkillDuck1(ObjectManager& parent_object_manager);
	
	virtual void	set_up(const Character* instance);

	// state ����(modify_time ����)
	virtual void	set_state(State state, const Uint32 modify_time);


	virtual bool	update(const TimeManager& tm);
	virtual void	draw(Renderer& renderer, const TimeManager& tm);

	virtual ~CharacterOnSkillDuck1();
};

