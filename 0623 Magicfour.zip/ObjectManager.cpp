#include "ObjectManager.h"
#include "SoundManager.h"
#include "global.h"
#include "MonsterOctopus.h"
#include "CharacterOnSkillOctopus1.h"
#include "CharacterOnSkillOctopus2.h"
#include "CharacterOnSkillBird1.h"
#include "CharacterOnSkillBird2.h"
#include "CharacterOnAttack.h"

ObjectManager::ObjectManager()
	: score(0)
{
	character_on_skill.push_back(std::make_shared<Character>(*this, 0));
	character_on_skill.push_back(std::make_shared<CharacterOnAttack>(*this));
	character_on_skill.push_back(std::make_shared<CharacterOnSkillDuck1>(*this));
	character_on_skill.push_back(std::make_shared<CharacterOnSkillDuck2>(*this));
	character_on_skill.push_back(std::make_shared<CharacterOnSkillOctopus1>(*this));
	character_on_skill.push_back(std::make_shared<CharacterOnSkillOctopus2>(*this));
	character_on_skill.push_back(std::make_shared<CharacterOnSkillBird1>(*this));
	character_on_skill.push_back(std::make_shared<CharacterOnSkillBird2>(*this));
	
	curr_character = character_on_skill[0];
}

void ObjectManager::start_spon(Uint32 spon_start_time)
{
	spon_start_time_ = spon_start_time;
	next_create_ = spon_start_time;
	spon_term = 8'000;
}

void ObjectManager::move(const TimeManager& tm)
{
	curr_character->run_move(tm);

	for (auto i = allies.begin(); i != allies.end(); ++i)
	{
		(*i)->run_move(tm);
	}
	
	for (auto i = enemies.begin(); i != enemies.end(); ++i)
	{
		(*i)->run_move(tm);
	}
	
	for (auto i = neutrals.begin(); i != neutrals.end(); ++i)
	{
		(*i)->run_move(tm);
	}
}

void ObjectManager::draw(Renderer& renderer, const TimeManager& tm)
{
	
	
	for (auto i = allies.begin(); i != allies.end(); ++i)
	{
		(*i)->draw(renderer, tm);
	}

	for (auto i = enemies.begin(); i != enemies.end(); ++i)
	{
		(*i)->draw(renderer, tm);
	}

	for (auto i = neutrals.begin(); i != neutrals.end(); ++i)
	{
		(*i)->draw(renderer, tm);
	}

	curr_character->draw(renderer, tm);

	if (score_texture == nullptr)
	{
		score_texture = renderer.make_text("Score : " + std::to_string(score), 0, WHITE);
		score_texture->center.x = score_texture->size.x + 10;
		score_texture->center.y = score_texture->size.y + 10;
	}
	renderer.enroll_texture(score_texture, { 1280, 720 }, 0, SDL_FLIP_NONE);
}

void ObjectManager::update(const TimeManager& tm, Renderer& renderer, SoundManager& sm) 
{
	while (next_create_ <= tm.get_curr())
	{
		// ���͸� ��ȯ�� ���� �Ǿ����� ���� ��ȯ
		int monster_species = RandomGenerator::rand(0, 2);
		switch (monster_species)
		{
		case 0:
			insert(std::make_shared<MonsterOctopus>(*this, tm.get_curr()), ObjectManager::ENEMIES);
			break;
		case 1:
			insert(std::make_shared<MonsterDuck>(*this, tm.get_curr()), ObjectManager::ENEMIES);
			break;
		case 2:
			insert(std::make_shared<MonsterBird>(*this, tm.get_curr()), ObjectManager::ENEMIES);
			break;
		}
		if ((next_create_ - spon_start_time_) / 30'000 < (next_create_ - spon_start_time_ + spon_term) / 30'000)
		{
			// 30�ʰ� ���� ������ ���� ���� ������ 90%�� ����.
			spon_term = spon_term * 9 / 10;
		}
		next_create_ += spon_term;
	}

	// ĳ������ ������Ʈ ó��
	if (curr_character->update(tm) == false)
	{
		change_character(0);
	}

	// �Ʊ��� ������Ʈ ó��
	for (auto i = allies.begin(); i != allies.end(); )
	{
		if ((*i)->update(tm) == false) i = allies.erase(i);
		else ++i;
	}

	// ������ ������Ʈ ó��
	for (auto i = enemies.begin(); i != enemies.end();)
	{
		if ((*i)->update(tm) == false) i = enemies.erase(i);
		else ++i;
	}

	// �߸��� ������Ʈ ó��
	for (auto i = neutrals.begin(); i != neutrals.end();)
	{
		if ((*i)->update(tm) == false) i = neutrals.erase(i);
		else ++i;
	}


	// [ĳ���� <-> ��] �� �浹 ó��
	for (auto j = enemies.begin(); j != enemies.end(); ++j)
	{
		if (curr_character->get_hittable() && (*j)->get_hittable() && curr_character->is_hit(**j))
		{
			curr_character->on_hit(*j, tm, renderer, sm);
			(*j)->on_hit(curr_character, tm, renderer, sm);
		}
	}

	// [ĳ���� �� �Ʊ� <-> ��] �� �浹 ó��
	for (auto i = allies.begin(); i != allies.end(); ++i)
	{
		if ((*i)->get_hittable() == false) continue;

		for (auto j = enemies.begin(); j != enemies.end(); ++j)
		{
			if ((*j)->get_hittable() == false) continue;

			if ((*i)->is_hit(**j))
			{
				(*i)->on_hit((*j), tm, renderer, sm);
				(*j)->on_hit((*i), tm, renderer, sm);
			}
		}
	}
}

void ObjectManager::change_character(int number)
{
	character_on_skill[number]->set_up(curr_character.get());
	curr_character->set_state(FieldObject::ERASED, 0);
	curr_character = character_on_skill[number];
}

void ObjectManager::add_score(int val)
{
	score += val;
	score_texture = nullptr;
}



void ObjectManager::insert(std::shared_ptr<FieldObject> field_object, ListName insert_target)
{
	switch (insert_target)
	{
	case ALLIES:
		allies.insert(field_object); break;

	case ENEMIES:
		enemies.insert(field_object); break;

	case NEUTRALS:
		neutrals.insert(field_object); break;
	}
}

ObjectManager::~ObjectManager()
{
}
