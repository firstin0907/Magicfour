#pragma once
#include "Monster.h"
class MonsterOctopus :
	public Monster
{
private:
	Uint32	next_change_;
	
public:
	static const int max_hp_ = 40;

public:
	MonsterOctopus(ObjectManager& parent_object_manager, Uint32 create_time);

	virtual void	set_state(State state, const Uint32 modify_time);

	virtual bool	update(const TimeManager& tm);
	virtual void	draw(Renderer& renderer, const TimeManager& tm);

	virtual ~MonsterOctopus();
};

