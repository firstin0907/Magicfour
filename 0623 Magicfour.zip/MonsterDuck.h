#pragma once
#include "Monster.h"

class MonsterDuck :
	public Monster
{
private:
	static constexpr double	JUMP_V = -1'300;
	static constexpr double	X_SPEED = 200;
	static constexpr Uint32 LANDING_TIME
		= static_cast<Uint32>(JUMP_V / GRAVITY * 1'000 * (-2));

	Uint32			next_jump_;

public:
	static const int max_hp_ = 30;
public:
	MonsterDuck(ObjectManager& parent_object_manager, Uint32 create_time);

	virtual void	set_state(State state, const Uint32 modify_time);

	virtual bool	update(const TimeManager& tm);
	virtual void	draw(Renderer& renderer, const TimeManager& tm);

	virtual ~MonsterDuck();
};