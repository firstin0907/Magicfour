#pragma once
#include "header.h"

class Initializer
{
public:
	Initializer();
	~Initializer();
};

