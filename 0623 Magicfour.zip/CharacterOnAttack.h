#pragma once
#include "Character.h"
class CharacterOnAttack :
	public Character
{
public:
	CharacterOnAttack(ObjectManager& parent_object_manager);

	virtual void	set_up(const Character* instance);

	// state ����(modify_time ����)
	virtual void	set_state(State state, const Uint32 modify_time);

	virtual bool	update(const TimeManager& tm);
	virtual void	draw(Renderer& renderer, const TimeManager& tm);

	~CharacterOnAttack();
};

