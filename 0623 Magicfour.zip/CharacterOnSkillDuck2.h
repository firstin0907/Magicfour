#pragma once
#include "Character.h"
class CharacterOnSkillDuck2 :
	public Character
{

protected:

	Uint32			next_drop_;
	int				cnt_;

	static constexpr Uint32		HIGHIST_TIME = 200;
	static constexpr Uint32		GO_DOWN_TIME = 1500;

	static constexpr double		GO_UP_V	= -6'000;
	static constexpr double		GO_DOWN_V = 12'000;

public:
	CharacterOnSkillDuck2(ObjectManager& parent_object_manager);
		
	virtual void	set_up(const Character* instance);

	// state ����(modify_time ����)
	virtual void	set_state(State state, const Uint32 modify_time);

	virtual bool	update(const TimeManager& tm);
	virtual void	draw(Renderer& renderer, const TimeManager& tm);

	virtual ~CharacterOnSkillDuck2();
};

