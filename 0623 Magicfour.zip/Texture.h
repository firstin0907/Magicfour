#pragma once
#include "header.h"

struct Texture
{
	SDL_Texture*	texture;
	Vector2d<int>	size;

	Point<int>		center;
	int				section_num;


public:
	operator SDL_Texture*();

	Texture(std::string img_file_name, std::string data_file_name,
		SDL_Renderer* renderer);
	Texture(std::string message, SDL_Renderer* renderer, TTF_Font* font,
		SDL_Color color = { 255, 255, 255, 255 });


	Texture(Texture&& t) noexcept;

	void draw(SDL_Renderer* renderer, Point<int> point, int section, SDL_RendererFlip flip);
	void draw(SDL_Renderer* renderer, Range<int> range, int section, SDL_RendererFlip flip);

	~Texture();
};

