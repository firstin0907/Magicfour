#include "Skill.h"



Skill::Skill(int id)
	: id(id)
{
}


void Skill::draw_icon(Renderer& renderer, int position)
{
	if (id == 0); // �� �׷�
	else;// �׷�
}

Skill::~Skill()
{
}
