#pragma once
#include "header.h"
#include "utility.h"

#include "App.h"
#include "Window.h"
#include "Renderer.h"
#include "Initializer.h"
#include "FieldObject.h"
#include "Monster.h"
#include "TimeManager.h"
#include "MonsterDuck.h"
#include "MonsterBird.h"
#include "ObjectManager.h"
#include "Character.h"
#include "CharacterOnSkillDuck1.h"
#include "CharacterOnSkillDuck2.h"
#include "DamageBox.h"

extern std::unique_ptr<App> app;